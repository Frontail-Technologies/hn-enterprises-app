import { ReactNode } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from "react-native";

import { controlHeight, radius, spacing } from "@/constants/spacing";
import { typography } from "@/constants/typography";
import { useTheme } from "@/context/ThemeContext";

type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "destructive";

type ButtonProps = {
  label: string;
  onPress?: () => void;
  variant?: ButtonVariant;
  icon?: ReactNode;
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
};

export function Button({
  label,
  onPress,
  variant = "primary",
  icon,
  disabled,
  loading,
  style,
}: ButtonProps) {
  const { colors } = useTheme();
  const resolved = variant === "outline" ? "secondary" : variant;
  const isPrimary = resolved === "primary";
  const isDestructive = resolved === "destructive";
  const isSecondary = resolved === "secondary";
  const isGhost = resolved === "ghost";

  const backgroundColor = isPrimary
    ? colors.primary
    : isDestructive
      ? colors.red
      : isSecondary
        ? colors.card
        : "transparent";
  const textColor = isPrimary || isDestructive ? "#FFFFFF" : isGhost ? colors.primary : colors.text;
  const height = isPrimary || isDestructive ? controlHeight.cta : controlHeight.input;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.base,
        {
          height,
          backgroundColor,
          borderColor: isSecondary ? colors.border : "transparent",
          borderWidth: isSecondary ? 1 : 0,
        },
        (disabled || loading) && styles.disabled,
        pressed && !disabled && !loading && styles.pressed,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={isPrimary || isDestructive ? "#FFFFFF" : colors.primary} />
      ) : (
        <View style={styles.contentRow}>
          {icon}
          <Text style={[styles.label, { color: textColor }]} numberOfLines={1}>
            {label}
          </Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    width: "100%",
    borderRadius: radius.button,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: spacing.xl,
  },
  disabled: {
    opacity: 0.5,
  },
  pressed: {
    opacity: 0.86,
  },
  contentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  label: {
    ...typography.button,
  },
});
