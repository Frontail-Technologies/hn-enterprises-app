import {
  Children,
  PropsWithChildren,
  ReactNode,
  isValidElement,
  useCallback,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  KeyboardAvoidingView,
  LayoutChangeEvent,
  Platform,
  RefreshControl,
  ScrollView,
  StyleProp,
  StyleSheet,
  View,
  ViewStyle,
} from "react-native";
import { Edge, SafeAreaView } from "react-native-safe-area-context";

import { spacing } from "@/constants/spacing";
import { ScrollIntoViewProvider } from "@/context/ScrollIntoViewContext";
import { useTheme } from "@/context/ThemeContext";
import { Reveal } from "./Reveal";

type KeyboardScrollTarget = Parameters<
  InstanceType<typeof ScrollView>["scrollResponderScrollNativeHandleToKeyboard"]
>[0];

type ScreenProps = PropsWithChildren<{
  scroll?: boolean;
  edges?: Edge[];
  contentStyle?: StyleProp<ViewStyle>;
  refreshable?: boolean;
  onRefresh?: () => void | Promise<void>;
  tabBarAware?: boolean;
  stickyHeader?: boolean;
  bottomAccessory?: ReactNode;
  revealContent?: boolean;
}>;

export function Screen({
  children,
  scroll = false,
  edges = ["top", "bottom"],
  contentStyle,
  refreshable = true,
  onRefresh,
  tabBarAware,
  stickyHeader = true,
  bottomAccessory,
  revealContent = true,
}: ScreenProps) {
  const { colors } = useTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [footerHeight, setFooterHeight] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  // The bottom tab bar is non-absolute, so the navigator already lays scenes out
  // above it and the bar's own paddingBottom covers the home indicator / gesture
  // bar. A tab-aware screen therefore only needs a small breathing gap above the
  // bar - it must NOT re-add the safe-area inset (that double-counts the indicator
  // and is what previously produced a background strip on non-scroll screens).
  const tabBarAwarePadding = tabBarAware ? spacing.lg : 0;
  const safeEdges = tabBarAware
    ? edges.filter((edge) => edge !== "bottom")
    : edges;
  const contentChildren = useMemo(() => Children.toArray(children), [children]);
  const scrollBottomPadding = Math.max(
    tabBarAwarePadding,
    bottomAccessory ? footerHeight + spacing.lg : 0,
  );
  const bottomPadding = scroll ? scrollBottomPadding : tabBarAwarePadding;
  const shouldStickFirstChild =
    stickyHeader && isHeaderLike(contentChildren[0]);
  const stickyHeaderIndices = shouldStickFirstChild ? [0] : undefined;
  const revealedChildren = useMemo(
    () =>
      revealContent
        ? contentChildren.map((child, i) =>
            shouldStickFirstChild && i === 0 ? (
              child
            ) : (
              <Reveal
                key={i}
                index={shouldStickFirstChild ? i - 1 : i}
                style={getChildFlexStyle(child)}
              >
                {child}
              </Reveal>
            ),
          )
        : contentChildren,
    [contentChildren, shouldStickFirstChild, revealContent],
  );

  // Screen no longer owns any query refetching - a screen passes an `onRefresh`
  // that refetches only its own query/query group.
  const canRefresh = refreshable && Boolean(onRefresh);
  const handleRefresh = useCallback(async () => {
    if (!onRefresh) return;
    setRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setRefreshing(false);
    }
  }, [onRefresh]);

  const handleFooterLayout = useCallback((event: LayoutChangeEvent) => {
    setFooterHeight(event.nativeEvent.layout.height);
  }, []);

  const scrollIntoView = useCallback(
    (node: unknown) => {
      if (!node) return;
      scrollViewRef.current?.scrollResponderScrollNativeHandleToKeyboard(
        node as KeyboardScrollTarget,
        footerHeight + 24,
        true,
      );
    },
    [footerHeight],
  );

  return (
    <SafeAreaView
      style={[styles.safeArea, { backgroundColor: colors.background }]}
      edges={safeEdges}
    >
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollIntoViewProvider value={scrollIntoView}>
          {scroll ? (
            <ScrollView
              ref={scrollViewRef}
              style={styles.flex}
              contentContainerStyle={[
                styles.content,
                contentStyle,
                bottomPadding > 0 && { paddingBottom: bottomPadding },
              ]}
              stickyHeaderIndices={stickyHeaderIndices}
              refreshControl={
                canRefresh ? (
                  <RefreshControl
                    refreshing={refreshing}
                    onRefresh={handleRefresh}
                    tintColor={colors.primaryDark}
                    colors={[colors.primaryDark]}
                    progressBackgroundColor={colors.card}
                  />
                ) : undefined
              }
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              {revealedChildren}
            </ScrollView>
          ) : (
            <View
              style={[
                styles.content,
                styles.flex,
                contentStyle,
                bottomPadding > 0 && { paddingBottom: bottomPadding },
              ]}
            >
              {revealedChildren}
            </View>
          )}
        </ScrollIntoViewProvider>
        {bottomAccessory ? (
          <View onLayout={handleFooterLayout}>{bottomAccessory}</View>
        ) : null}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function getChildFlexStyle(child: ReactNode): StyleProp<ViewStyle> {
  if (!isValidElement(child)) return undefined;
  const style = (child.props as { style?: StyleProp<ViewStyle> } | null)?.style;
  const flattened = StyleSheet.flatten(style);
  if (!flattened) return undefined;

  const passthrough: ViewStyle = {};
  if (typeof flattened.flex === "number") passthrough.flex = flattened.flex;
  if (flattened.width !== undefined) passthrough.width = flattened.width;
  if (flattened.alignSelf !== undefined)
    passthrough.alignSelf = flattened.alignSelf;

  return Object.keys(passthrough).length ? passthrough : undefined;
}

// Sticky-header detection uses an explicit static marker set on the header
// components rather than the function name, which is mangled by production
// minification (breaking sticky headers only in release builds).
function isHeaderLike(child: ReactNode) {
  if (!isValidElement(child)) return false;
  const type = child.type as { isStickyHeader?: boolean } | null;
  return type?.isStickyHeader === true;
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 8,
  },
});
